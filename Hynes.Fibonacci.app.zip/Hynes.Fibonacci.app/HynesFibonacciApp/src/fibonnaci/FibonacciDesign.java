package fibonnaci;

public class FibonacciDesign
{
	public int inputfibonaccinumber;
	//input a number of the Fibonacci sequence
}
{
	public int Fibonaccinum;
	// show first 50 numbersof the Fibonacci Sequence
}
