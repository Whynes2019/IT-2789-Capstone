package fibonnaci;

import javax.swing.JOptionPane;

public class FibonacciApp {

	FibonacciApp()
	{
	Public int fibonaccinumbers;
	{
		int n1=0,n2=1,n3i,count=50;
		JOptionPane.showMessageDialog=(n1+ ""+n2 );
		while(n1<51)
		{JOptionPane.showMessageDialog=(n1+ ",");
		int nextTerm = n1 + n2;
		n1=n2;
		n2=nextTerm;
		}
	}
	}
}
